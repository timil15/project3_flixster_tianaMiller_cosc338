package com.example.flixster.models

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

data class Movie(
    val title: String,
    val overview: String,
    val posterPath: String
) {
    fun getPosterUrl(): String {
        return "https://image.tmdb.org/t/p/w500/$posterPath"
    }

    companion object {
        fun fromJsonArray(jsonArray: JSONArray): List<Movie> {
            val movies = mutableListOf<Movie>()
            for (i in 0 until jsonArray.length()) {
                val movieJson = jsonArray.getJSONObject(i)
                val movie = Movie(
                    title = movieJson.getString("title"),
                    overview = movieJson.getString("overview"),
                    posterPath = movieJson.getString("poster_path")
                )
                movies.add(movie)
            }
            return movies
        }
    }
}
