package com.example.flixster

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.flixster.models.Movie
import com.example.flixster.adapters.MovieAdapter
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.JsonHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONException

class MainActivity : AppCompatActivity() {

    private lateinit var rvMovies: RecyclerView
    private val movies = ArrayList<Movie>()
    private lateinit var movieAdapter: MovieAdapter

    private val NOW_PLAYING_URL =
        "https://api.themoviedb.org/3/movie/now_playing?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMovies = findViewById(R.id.rvMovies)

        movieAdapter = MovieAdapter(this, movies)
        rvMovies.adapter = movieAdapter
        rvMovies.layoutManager = LinearLayoutManager(this)

        val client = AsyncHttpClient()
        client.get(NOW_PLAYING_URL, object : JsonHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                response: org.json.JSONObject?
            ) {
                try {
                    val results = response?.getJSONArray("results")
                    if (results != null) {
                        movies.addAll(Movie.fromJsonArray(results))
                        movieAdapter.notifyDataSetChanged()
                    }
                } catch (e: JSONException) {
                    Log.e("MainActivity", "JSON exception", e)
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                throwable: Throwable?,
                errorResponse: org.json.JSONObject?
            ) {
                Log.e("MainActivity", "Request failed", throwable)
            }
        })
    }
}
